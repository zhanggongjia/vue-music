<template>
  <div class="singer">
  
  </div>
</template>

<script>



</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
